# Scorpions et gerbilles : dynamique des populations et modèle neuronal de la prédation 
This project was developped during the introductory object oriented programming course (CS-112(i)) at EPFL.

This project was tested :
     - On Linux Mint 18.2 Cinnamon 64-bit
     - On Ubuntu VM on CO thinclient at epfl.

## Prerequisites

    - scons
    - [SFML](https://www.sfml-dev.org/documentation/2.3/)

## Build

```
    cd partie6
```
